
	const data = {"ban":{"data":".silicon-ban {\n  /* position */\n  position: relative;\n  /* size */\n  display: inline-block;\n  box-sizing: border-box;\n  width: 1em;\n  height: 1em;\n  /* background  */\n  background-image: linear-gradient(to right bottom, transparent calc(50% - (var(--stroke, 0.1em) * 0.5)), currentColor calc(50% - (var(--stroke, 0.1em) * 0.5)), currentColor calc(50% + (var(--stroke, 0.1em) * 0.5)), transparent calc(50% - (var(--stroke, 0.1em) * 0.5)));\n  /* border */\n  border: var(--stroke, 0.1em) solid currentColor;\n  border-radius: 50%;\n}"}}
	export default data; 
	